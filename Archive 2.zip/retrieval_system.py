from abc import ABC, abstractmethod
from pathlib import Path


class RetrievalSystem(ABC):
    def __init__(self):
        self.data = None
        self.titles_data = None

    @abstractmethod
    def load_model(self, model_path):
        pass

    def load_data(self, data_path, titles_path):
        # Load the data to be processed, assuming one sentence or title per line
        with Path.open(data_path, encoding="utf-8") as f:
            self.data = [line.strip() for line in f if line.strip()]
        with Path.open(titles_path, encoding="utf-8") as f:
            self.titles_data = [line.strip() for line in f if line.strip()]
        print("Data loaded successfully.")

    @abstractmethod
    def process_data(self):
        pass

    @abstractmethod
    def compare_data(self):
        pass

    def get_topk_per_title(self, titles_dict, k):
        topk = {}
        for title, similar_titles in titles_dict.items():
            topk[title] = similar_titles[:k]
        return topk

    def get_topk_absolute(self, titles_dict, k=5, similarity_threshold=0.8):
        topk = {}
        for title, similar_titles in titles_dict.items():
            topk[title] = similar_titles[:k]
        for title, similar_titles in topk.items():
            topk[title] = [
                (similar_title, similarity)
                for similar_title, similarity in similar_titles
                if similarity > similarity_threshold
            ]
            topk = {
                title: similar_titles for title, similar_titles in topk.items() if similar_titles
            }
            if not topk:
                print("No similar titles found.")

        return topk

    def print_results(self, topk_per_title):
        for title, similar_docs in topk_per_title.items():
            print(f"Title: {title[:50]} {'...' if len(title) > 50 else ''}")
            for doc, similarity in similar_docs:
                print(f"Document: {doc}, Similarity: {similarity:.4f}")
            print()

    def save_results(self, topk_per_title, output_path):
        with Path.open(output_path, "w", encoding="utf-8") as f:
            for title, similar_docs in topk_per_title.items():
                f.write(f"Title: {title[:50]} {'...' if len(title) > 50 else ''}\n")
                for doc, similarity in similar_docs:
                    f.write(f"Document: {doc}, Similarity: {similarity:.4f}\n")
                f.write("\n")
        print(f"Results saved to {output_path}.")
