from retrieval_system import RetrievalSystem
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import KNeighborsClassifier


class KNNProcessor(RetrievalSystem):
    def load_model(self, model_path=None):
        # KNN doesn't require a pre-trained model, so we can skip loading a model
        self.vectorizer = TfidfVectorizer()
        self.knn = None
        print("KNN Processor initialized successfully.")

    def process_data(self):
        # Check if data is loaded
        if self.data is None or self.titles_data is None:
            raise ValueError("Data is not loaded. Call load_data() first.")

        # Fit the vectorizer on the combined data
        combined_data = self.data + self.titles_data
        self.tfidf_matrix = self.vectorizer.fit_transform(combined_data)

        # Split the tfidf matrix back into data and titles
        self.data_tfidf = self.tfidf_matrix[:len(self.data)]
        self.titles_tfidf = self.tfidf_matrix[len(self.data):]

        # Initialize and fit the KNN classifier
        self.knn = KNeighborsClassifier(n_neighbors=5, metric='cosine')
        self.knn.fit(self.data_tfidf, list(range(len(self.data))))
        print("Data processed and KNN model fitted successfully.")

    def compare_data(self):
        # Check if the KNN model is fitted
        if self.knn is None or self.titles_tfidf is None:
            raise ValueError("Model is not fitted or data is not processed. Call process_data() first.")

        titles_dict = {}
        for idx, title_vec in enumerate(self.titles_tfidf):
            # Find the k-nearest neighbors for each title
            distances, indices = self.knn.kneighbors(title_vec, n_neighbors=5)
            title = self.titles_data[idx]
            titles_dict[title] = [(self.data[i], 1 - distances[0][j]) for j, i in enumerate(indices[0])]

        print("Data compared using KNN successfully.")
        return titles_dict
