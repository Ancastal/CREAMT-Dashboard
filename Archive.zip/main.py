import argparse
import time

from embedding_processor import EmbeddingProcessor
from knn_processor import KNNProcessor


def main():
    parser = argparse.ArgumentParser(
        description="Choose a retrieval method to find similar documents."
    )
    parser.add_argument(
        "method",
        choices=["embedding", "knn"],
        help="Retrieval method to use: 'embedding' or 'knn'",
    )
    parser.add_argument(
        "--model_path",
        type=str,
        required=False,
        help="Path to the model (required for 'embedding')",
    )
    parser.add_argument(
        "--data_path", type=str, required=True, help="Path to the general domain documents file"
    )
    parser.add_argument(
        "--titles_data_path", type=str, required=True, help="Path to the in-domain titles file"
    )
    parser.add_argument(
        "--top_k", type=int, default=5, help="Number of top similar documents to retrieve"
    )
    parser.add_argument(
        "--similarity_threshold",
        type=float,
        default=0.8,
        help="Similarity threshold for top-k absolute retrieval",
    )
    args = parser.parse_args()

    # Initialize the chosen processor
    if args.method == "embedding":
        if not args.model_path:
            parser.error("--model_path is required for the 'embedding' method")
        processor = EmbeddingProcessor()
        processor.load_model(args.model_path)
    elif args.method == "knn":
        processor = KNNProcessor()
        processor.load_model()  # No model path needed for KNN

    # Load data
    start_time = time.time()
    processor.load_data(args.data_path, args.titles_data_path)
    end_time = time.time()
    print(f"Data loaded in {end_time - start_time:.2f} seconds.")

    # Process data
    start_time = time.time()
    processor.process_data()
    end_time = time.time()
    print(f"Data processed in {end_time - start_time:.2f} seconds.")

    # Compare data
    start_time = time.time()
    titles_dict = processor.compare_data()
    end_time = time.time()
    print(f"Data compared in {end_time - start_time:.2f} seconds.")

    # Get top-k absolute similar documents
    start_time = time.time()
    topk_absolute = processor.get_topk_absolute(titles_dict, args.top_k)
    end_time = time.time()
    print(
        f"Top {args.top_k} absolute similar documents retrieved in {end_time - start_time:.2f} seconds."
    )

    # Print the results
    for title, similar_docs in topk_absolute.items():
        print(f"Title: {title}")
        for doc, similarity in similar_docs:
            print(f"  Similar Document: {doc} (Similarity: {similarity:.4f})")
        print()


if __name__ == "__main__":
    main()
