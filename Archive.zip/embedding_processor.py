
import numpy as np
from retrieval_system import RetrievalSystem
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from pathlib import Path

class EmbeddingProcessor(RetrievalSystem):
    def __init__(self, model_path):
        if model_path is not None:
            self.load_model(model_path)

    def load_model(self, model_path):
        self.model = SentenceTransformer(model_path)
        print("Model loaded successfully.")

    def load_data(self, data_path, titles_path):
        # Load data and titles
        self.data = self._load_data_from_file(data_path)
        self.titles_data = self._load_data_from_file(titles_path)
        print("Data loaded successfully.")

    def _load_data_from_file(self, file_path):
        with Path.open(file_path, 'r') as f:
            data = f.readlines()
        return data

    def process_data(self):
        # Check if data is loaded
        if self.data is None or self.titles_data is None:
            raise ValueError("Data is not loaded. Call load_data() first.")
        # Embed the data using the loaded model
        self.embeddings = self.model.encode(self.data, convert_to_tensor=True)
        self.titles_embeddings = self.model.encode(self.titles_data, convert_to_tensor=True)
        print("Data embedded successfully.")

    def compare_data(self):
        # Check if embeddings are generated
        if self.embeddings is None or self.titles_embeddings is None:
            raise ValueError("Embeddings are not generated. Call process_data() first.")

        # Move tensors to CPU before converting to numpy for sklearn processing
        self.embeddings = self.embeddings.cpu().numpy()
        self.titles_embeddings = self.titles_embeddings.cpu().numpy()

        titles_dict = {}
        # Calculate cosine similarity between each title and all data embeddings
        similarities = cosine_similarity(self.titles_embeddings, self.embeddings)
        for idx, title in enumerate(self.titles_data):
            # Get top indices based on similarity scores
            top_indices = np.argsort(-similarities[idx])  # Negative for descending order
            titles_dict[title] = [(self.data[j], similarities[idx][j]) for j in top_indices]
        print("Embeddings compared successfully.")
        return titles_dict
